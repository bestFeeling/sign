module.exports = {
	DB:{
		db: 'mssql',
		dbname: 'sign',
		dbaddress: '192.168.3.233',
		user: 'sa',
		pw: 'Xtep@2008!@'
	},
	DB_Test: {
		db: 'mysql',
		dbname: 'sign',
		dbaddress: '114.215.113.108',
		user: 'admin',
		pw: 'admin2015'
	}
}